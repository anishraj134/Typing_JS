/**
 * This script implements the falling letters game in JavaScript and RightJS
 *
 * You can play with the thing over here
 *   http://stcamp.net/games/t-ninja
 *
 * Copyright (C) 2009 Nikolay V. Nemshilov aka St.
 */
